# Heisenberg
Voice Assistant in python 

#### Packages needs to install

<!-- Code block-->

```bash
pip install pyttsx3
pip install wikipedia
pip install requests
pip install PyAutoGUI
pip install sounddevice
pip install playsound
pip install wolframalpha
pip install urllib3
pip install bs4
pip install wheel
pip install google-api-python-client
pip install monotonic
pip install SpeechRecognition
pip install scipy
pip install threaded
pip install functools
pip install pywhatkit
pip install pyjokes
pip install pygame
pip install pyperclip
pip install opencv-python
pip install pysqlite3
pip install db-sqlite3
```
For installation of pyaudio
```bash
pip intall pipwin
pipwin install pyaudio
pip install --upgrade pyaudio
```
#####Maybe all modules which are imported in code are not listed here. So install them respectively if you encounter with a error like ModuleNotFound.
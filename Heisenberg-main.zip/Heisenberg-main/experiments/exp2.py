class A:
    a=4
    def ok(self):
        print(a)


m=A()

m.ok()

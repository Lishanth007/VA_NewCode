import pyautogui

# pyautogui.alert('This is an alert box.')        #shows an alert box
# pyautogui.confirm('Shall I proceed?')           #ok and cancle 
# pyautogui.confirm('Enter option.', buttons=['A', 'B', 'C'])     #buttons
# pyautogui.prompt('What is your name?')          #takes input
# pyautogui.password('Enter password (text will be hidden)')      

# pyautogui.moveTo(100, 150) # Move the mouse to the x, y coordinates 100, 150.
# pyautogui.click()             # Click the mouse at its current location.
# pyautogui.click(200, 220) # Click the mouse at the x, y coordinates 200, 220.
# pyautogui.move(None, 10)  # Move mouse 10 pixels down, that is, move the mouse relative to its current position.
# pyautogui.write('Hello world!', interval=0.25)  # Type with quarter-second pause in between each key.
# pyautogui.press('alt') # Simulate pressing the Escape key.

# im1 = pyautogui.screenshot()
# im1.save()